﻿namespace JewelCollectorGame;

public class JewelCollector {

    public static void Main() {
  
        bool running = true;
        Map.StartMap();
        Robot rob = new Robot(0,0);
        
        // Insert objects in map
        Map.InsertInMap(rob);
        Map.InsertInMap(new Jewel(1,9, "JR"));
        Map.InsertInMap(new Jewel(8,8, "JR"));
        Map.InsertInMap(new Jewel(9,1, "JG"));
        Map.InsertInMap(new Jewel(7,6, "JG"));
        Map.InsertInMap(new Jewel(3,4, "JB"));
        Map.InsertInMap(new Jewel(2,1, "JB"));
        Map.InsertInMap(new Obstacle(5,0, "##"));
        Map.InsertInMap(new Obstacle(5,1, "##"));
        Map.InsertInMap(new Obstacle(5,2, "##"));
        Map.InsertInMap(new Obstacle(5,3, "##"));
        Map.InsertInMap(new Obstacle(5,4, "##"));
        Map.InsertInMap(new Obstacle(5,5, "##"));
        Map.InsertInMap(new Obstacle(5,6, "##"));
        Map.InsertInMap(new Obstacle(5,9, "$$"));
        Map.InsertInMap(new Obstacle(3,9, "$$"));
        Map.InsertInMap(new Obstacle(5,9, "$$"));
        Map.InsertInMap(new Obstacle(8,3, "$$"));
        Map.InsertInMap(new Obstacle(2,5, "$$"));

        do {
            Map.PrintMap();

            Console.WriteLine("Enter the command: ");
            string? command = Console.ReadLine();
            if (command != null){
                if (command.Equals("quit")) {
                    running = false;
                } else if (command.Equals("w")) {
                    rob.Move(command);
                } else if (command.Equals("a")) {
                    rob.Move(command);
                } else if (command.Equals("s")) {
                    rob.Move(command);
                } else if (command.Equals("d")) {
                    rob.Move(command);
                } else if (command.Equals("g")) {
                    rob.GetAdjacent();
                }
            }    
            
        } while (running);
  }
}

