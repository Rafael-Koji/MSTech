﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

// Primitive Types
// Integers with signal
sbyte s = 20;
short t = 5;
int i = 10;
long l = -3000;

// Integers without signal
byte b = 255;
ushort us = 2;
uint ui = 5;
ulong ul = 5000;

// Real type data
float f = 3.14F; //4 bytes, will not compile without suffix F
double d = 1.23; //8 bytes, sufixo redundante
decimal g = 2.32M; //16 bytes, will not compile without suffix M

// Numerical integer can be denoted by binary, decimal, hexadecimal notation
int bi = 0b1010_1011_1100_1101_1110_1111; //Needs 0b prefix
int x = 127;
long y = 0x7F; //Needs 0x prefix

// Other types of notations
int million = 1_000_000; //Underscore is ignored
double doubleMillion = 1e06; //Exponential notation, necessary suffix e

// Type conversion 
long l = i; //Can be implicit if the destination type can represent the value
short t = short(i); //Must be explicit otherwise

